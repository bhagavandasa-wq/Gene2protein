BiocManager::install("EnsDb.Hsapiens.v86", ask = FALSE, force = TRUE)
library(EnsDb.Hsapiens.v86)
library(ensembldb)
edb <- EnsDb.Hsapiens.v86
tx <- transcripts(edb, filter = GeneNameFilter("ESR1"))
tx
prots <- proteins(edb, filter = GeneNameFilter("ESR1"))
prots
cds <- cdsBy(edb, by = "tx", filter = GeneNameFilter("ESR1"))
cds <- cdsBy(edb, by = "tx", filter = GeneNameFilter("ESR1"))
cds
columns(edb)


prots <- proteins(edb, filter = GeneNameFilter("CYP3A4"))
prot_ids <- prots$protein_id
prot2genome <- select(edb,
                      keys = prot_ids,
                      keytype = "PROTEINID",
                      columns = c("PROTEINID", "TXID", "GENEID", "SEQNAME"))
prot2genome